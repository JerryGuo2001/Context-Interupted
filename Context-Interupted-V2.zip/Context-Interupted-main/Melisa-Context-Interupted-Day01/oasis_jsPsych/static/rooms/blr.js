function shuffle(array) {
  array.sort(() => Math.random() - 0.5);
}
var blr_background = 'white'

var blr_scene = [""]

var redx=['redx.jpg']

var blr_val = ['pan', 'lagoon', 'knife', 'sword', 'canvas', 'bell', 'kazoo', 'wine', 'ladder', 'cottage', 'angel', 'jawbone', 'boat', 'bull', 'goulash', 'anaconda', 'mantle', 'tabasco', 'statue', 'soot', 'award', 'heater', 'boulder', 'seed', 'plastic', 'football', 'carpet', 'blade', 'pheasant', 'vein']

