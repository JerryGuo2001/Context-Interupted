function shuffle(array) {
  array.sort(() => Math.random() - 0.5);
}
var yellow_background = 'white'

var yellow_scene = ["Yellow_Fabric.jpg"]

var redx=['redx.jpg']

var yellow_val = ['crystal','ship','cereal','sponge','acid','cigar','marble','cattle','bench','sheath','dice','anvil','hardware','meadow','onion','bone','lock','deck','clover','sail','shark','blood','grave','tripod','egg','penny','spark','candy','apricot','spectacle','poultry','jeep','yarn','roll','sheet','anaconda','angel','wine','pan','jawbone','lagoon','sword','seed','heater','bell','bus','soil','brass','canal','lodge','monument','pelvis','falcon','lime','tooth','belt','ranch','stake','grill','root','board','grail','honey','shelf','tadpole','spoke','ginseng','cardinal','tongue','palm','cone','potato','fireplace','timber','oil','door','envelope','squid','crab','watch']
