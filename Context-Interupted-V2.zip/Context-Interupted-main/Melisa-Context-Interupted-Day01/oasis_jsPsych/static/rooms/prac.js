function shuffle(array) {
  array.sort(() => Math.random() - 0.5);
}
var prac_background = 'white'
var prac_scene = ["Purple_Fabric.jpg"]

var redx=['redx.jpg']

var prac_val = ['abacus',
  'beer',
  'book',
  'leather',
  'car',
  'elastic',
  'mint',
  'pear',]

