var all_images = ['../static/images/Blue_Fabric.jpg','../static/images/isi.png']
